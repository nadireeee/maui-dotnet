﻿using MovieApp.Maui.Views;

namespace MovieApp.Maui;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();

		Routing.RegisterRoute(nameof(LoginPage), typeof(LoginPage));
		Routing.RegisterRoute(nameof(RegisterPage), typeof(RegisterPage));
		Routing.RegisterRoute(nameof(PasswordUpdatePage), typeof(PasswordUpdatePage));
		Routing.RegisterRoute(nameof(FilmListPage), typeof(FilmListPage));
		Routing.RegisterRoute(nameof(FilmDetailPage), typeof(FilmDetailPage));
		Routing.RegisterRoute(nameof(ProfilePage), typeof(ProfilePage));
	}
}
