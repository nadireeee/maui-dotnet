using System.Diagnostics;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using MovieApp.Maui.Models;
using Microsoft.Maui.Controls;

namespace MovieApp.Maui.Services;

public class ApiService
{
    private readonly HttpClient _httpClient;
    private readonly string _baseUrl;
    private string? _authToken;

    public ApiService()
    {
        _baseUrl = GetBaseUrl();
        Debug.WriteLine($"API Base URL: {_baseUrl}");
        
        _httpClient = new HttpClient
        {
            BaseAddress = new Uri(_baseUrl),
            Timeout = TimeSpan.FromSeconds(30)
        };
        
        // Add default headers
        _httpClient.DefaultRequestHeaders.Accept.Clear();
        _httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
    }

    private string GetBaseUrl()
    {
        if (DeviceInfo.Platform == DevicePlatform.Android)
        {
            return "http://10.0.2.2:5175/api";
        }
        else if (DeviceInfo.Platform == DevicePlatform.iOS)
        {
            return "http://localhost:5175/api";
        }
        else
        {
            return "http://localhost:5175/api";
        }
    }

    public void SetToken(string token)
    {
        _authToken = token;
        _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
    }

    private StringContent SerializeContent(object obj) =>
        new(JsonSerializer.Serialize(obj), Encoding.UTF8, "application/json");

    private async Task<T?> DeserializeResponse<T>(HttpResponseMessage response)
    {
        var content = await response.Content.ReadAsStringAsync();
        return JsonSerializer.Deserialize<T>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
    }

    public async Task<User?> LoginAsync(string username, string password)
    {
        try
        {
            Debug.WriteLine($"Login attempt for user: {username}");
            var requestContent = new { Username = username, Password = password };
            var content = SerializeContent(requestContent);
            Debug.WriteLine($"Request URL: {_baseUrl}/api/users/login");
            Debug.WriteLine($"Request Content: {await content.ReadAsStringAsync()}");
            
            var response = await _httpClient.PostAsync("/api/users/login", content);
            Debug.WriteLine($"Response Status: {response.StatusCode}");
            
            if (response.IsSuccessStatusCode)
            {
                var loginResponse = await DeserializeResponse<LoginResponse>(response);
                Debug.WriteLine($"Login successful for user: {username}");
                if (!string.IsNullOrEmpty(loginResponse?.Token))
                {
                    SetToken(loginResponse.Token);
                    Debug.WriteLine("Token set successfully");
                }
                return loginResponse?.User;
            }
            else
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                Debug.WriteLine($"Login failed. Status: {response.StatusCode}, Error: {errorContent}");
            }
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"Login error: {ex.Message}");
            Debug.WriteLine($"Stack trace: {ex.StackTrace}");
        }
        return null;
    }

    public async Task<User?> RegisterAsync(User user)
    {
        try
        {
            Debug.WriteLine($"Register attempt for user: {user.Username}");
            var content = SerializeContent(user);
            Debug.WriteLine($"Request URL: {_baseUrl}/api/users/register");
            Debug.WriteLine($"Request Content: {await content.ReadAsStringAsync()}");
            
            var response = await _httpClient.PostAsync("/api/users/register", content);
            Debug.WriteLine($"Response Status: {response.StatusCode}");
            
            if (response.IsSuccessStatusCode)
            {
                var registeredUser = await DeserializeResponse<User>(response);
                Debug.WriteLine($"Registration successful for user: {user.Username}");
                return registeredUser;
            }
            else
            {
                var errorContent = await response.Content.ReadAsStringAsync();
                Debug.WriteLine($"Registration failed. Status: {response.StatusCode}, Error: {errorContent}");
            }
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"Register error: {ex.Message}");
            Debug.WriteLine($"Stack trace: {ex.StackTrace}");
        }
        return null;
    }

    public async Task<bool> UpdatePasswordAsync(string email, string currentPassword, string newPassword)
    {
        try
        {
            var response = await _httpClient.PutAsync("/api/users/update-password",
                SerializeContent(new { Email = email, CurrentPassword = currentPassword, NewPassword = newPassword }));
            return response.IsSuccessStatusCode;
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"UpdatePassword error: {ex.Message}");
            return false;
        }
    }

    public async Task<List<Movie>> GetMoviesAsync()
    {
        try
        {
            var response = await _httpClient.GetAsync("/api/movies");
            return response.IsSuccessStatusCode ? (await DeserializeResponse<List<Movie>>(response)) ?? new() : new();
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"GetMovies error: {ex.Message}");
            return new();
        }
    }

    public async Task<Movie?> GetMovieByIdAsync(int id)
    {
        try
        {
            var response = await _httpClient.GetAsync($"/api/movies/{id}");
            return response.IsSuccessStatusCode ? await DeserializeResponse<Movie>(response) : null;
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"GetMovieById error: {ex.Message}");
            return null;
        }
    }

    public async Task<User?> GetUserByIdAsync(int id)
    {
        try
        {
            var response = await _httpClient.GetAsync($"/api/users/{id}");
            return response.IsSuccessStatusCode ? await DeserializeResponse<User>(response) : null;
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"GetUserById error: {ex.Message}");
            return null;
        }
    }

    public async Task<UserRating?> GetUserRatingAsync(int userId, int movieId)
    {
        try
        {
            var response = await _httpClient.GetAsync($"/api/users/{userId}/ratings/{movieId}");
            return response.IsSuccessStatusCode ? await DeserializeResponse<UserRating>(response) : null;
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"GetUserRating error: {ex.Message}");
            return null;
        }
    }

    public async Task<UserRating?> CreateUserRatingAsync(UserRating rating)
    {
        try
        {
            var response = await _httpClient.PostAsync($"/api/users/{rating.UserId}/ratings", SerializeContent(rating));
            return response.IsSuccessStatusCode ? await DeserializeResponse<UserRating>(response) : null;
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"CreateUserRating error: {ex.Message}");
            return null;
        }
    }

    public async Task<UserRating?> UpdateUserRatingAsync(UserRating rating)
    {
        try
        {
            var response = await _httpClient.PutAsync($"/api/users/{rating.UserId}/ratings/{rating.MovieId}", SerializeContent(rating));
            return response.IsSuccessStatusCode ? await DeserializeResponse<UserRating>(response) : null;
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"UpdateUserRating error: {ex.Message}");
            return null;
        }
    }

    public async Task<bool> TestConnectionAsync()
    {
        try
        {
            Debug.WriteLine($"Testing connection to: {_baseUrl}");
            
            // Test users endpoint
            var usersResponse = await _httpClient.GetAsync("/api/users");
            Debug.WriteLine($"Users endpoint response: {usersResponse.StatusCode}");
            var usersContent = await usersResponse.Content.ReadAsStringAsync();
            Debug.WriteLine($"Users response content: {usersContent}");

            return usersResponse.IsSuccessStatusCode;
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"Test connection error: {ex.Message}");
            Debug.WriteLine($"Stack trace: {ex.StackTrace}");
            return false;
        }
    }
}

public class LoginResponse
{
    public string Token { get; set; } = string.Empty;
    public User? User { get; set; }
}
