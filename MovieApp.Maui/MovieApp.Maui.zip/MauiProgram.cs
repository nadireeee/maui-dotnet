using Microsoft.Extensions.Logging;
using MovieApp.Maui.Services;
using MovieApp.Maui.ViewModels;
using MovieApp.Maui.Views;
using CommunityToolkit.Maui;

namespace MovieApp.Maui;

public static class MauiProgram
{
	public static MauiApp CreateMauiApp()
	{
		var builder = MauiApp.CreateBuilder();
		builder
			.UseMauiApp<App>()
			.UseMauiCommunityToolkit()
			.ConfigureFonts(fonts =>
			{
				fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
				fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
			});

#if DEBUG
		builder.Logging.AddDebug();
#endif

		// Register services
		builder.Services.AddSingleton<ApiService>();

		// ViewModels
		builder.Services.AddTransient<MovieListViewModel>();
		builder.Services.AddTransient<LoginViewModel>();
		builder.Services.AddTransient<RegisterViewModel>();

		// Pages
		builder.Services.AddTransient<FilmListPage>();
		builder.Services.AddTransient<LoginPage>();
		builder.Services.AddTransient<RegisterPage>();

		return builder.Build();
	}
}
