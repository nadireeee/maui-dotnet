using System.ComponentModel;
using System.Runtime.CompilerServices;
using MovieApp.Maui.Models;
using MovieApp.Maui.Services;
using System.Diagnostics;

namespace MovieApp.Maui.ViewModels;

public class LoginViewModel : INotifyPropertyChanged
{
    private readonly ApiService _apiService;
    private string _username = string.Empty;
    private string _password = string.Empty;
    private bool _isBusy;
    private string _errorMessage = string.Empty;

    public LoginViewModel(ApiService apiService)
    {
        _apiService = apiService;
        LoginCommand = new Command(async () => await LoginAsync());
    }

    public string Username
    {
        get => _username;
        set
        {
            if (_username != value)
            {
                _username = value;
                OnPropertyChanged();
            }
        }
    }

    public string Password
    {
        get => _password;
        set
        {
            if (_password != value)
            {
                _password = value;
                OnPropertyChanged();
            }
        }
    }

    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (_isBusy != value)
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }
    }

    public string ErrorMessage
    {
        get => _errorMessage;
        set
        {
            if (_errorMessage != value)
            {
                _errorMessage = value;
                OnPropertyChanged();
            }
        }
    }

    public Command LoginCommand { get; }

    private async Task LoginAsync()
    {
        if (IsBusy)
            return;

        try
        {
            IsBusy = true;
            ErrorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(Username) || string.IsNullOrWhiteSpace(Password))
            {
                ErrorMessage = "Kullanıcı adı ve şifre gereklidir.";
                return;
            }

            Debug.WriteLine($"Login attempt started for user: {Username}");
            var user = await _apiService.LoginAsync(Username, Password);
            
            if (user != null)
            {
                Debug.WriteLine($"Login successful for user: {Username}");
                // Başarılı giriş sonrası yönlendirme
                await Shell.Current.GoToAsync("FilmListPage");
            }
            else
            {
                Debug.WriteLine($"Login failed for user: {Username}");
                ErrorMessage = "Giriş başarısız. Lütfen bilgilerinizi kontrol edin.";
            }
        }
        catch (Exception ex)
        {
            Debug.WriteLine($"Login error in ViewModel: {ex.Message}");
            Debug.WriteLine($"Stack trace: {ex.StackTrace}");
            ErrorMessage = $"Giriş yapılırken bir hata oluştu: {ex.Message}";
        }
        finally
        {
            IsBusy = false;
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
} 