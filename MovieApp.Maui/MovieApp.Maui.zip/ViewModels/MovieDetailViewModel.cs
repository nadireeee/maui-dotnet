using System.ComponentModel;
using System.Runtime.CompilerServices;
using MovieApp.Maui.Models;
using MovieApp.Maui.Services;

namespace MovieApp.Maui.ViewModels;

public class MovieDetailViewModel : INotifyPropertyChanged
{
    private readonly ApiService _apiService;
    private Movie? _movie;
    private UserRating? _userRating;
    private double _rating;
    private string _review = string.Empty;
    private bool _isBusy;
    private string _errorMessage = string.Empty;

    public MovieDetailViewModel(ApiService apiService)
    {
        _apiService = apiService;
        SaveRatingCommand = new Command(async () => await SaveRatingAsync());
    }

    public Movie? Movie
    {
        get => _movie;
        set
        {
            if (_movie != value)
            {
                _movie = value;
                OnPropertyChanged();
            }
        }
    }

    public UserRating? UserRating
    {
        get => _userRating;
        set
        {
            if (_userRating != value)
            {
                _userRating = value;
                OnPropertyChanged();
            }
        }
    }

    public double Rating
    {
        get => _rating;
        set
        {
            if (_rating != value)
            {
                _rating = value;
                OnPropertyChanged();
            }
        }
    }

    public string Review
    {
        get => _review;
        set
        {
            if (_review != value)
            {
                _review = value;
                OnPropertyChanged();
            }
        }
    }

    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (_isBusy != value)
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }
    }

    public string ErrorMessage
    {
        get => _errorMessage;
        set
        {
            if (_errorMessage != value)
            {
                _errorMessage = value;
                OnPropertyChanged();
            }
        }
    }

    public Command SaveRatingCommand { get; }

    public async Task LoadMovieAsync(int movieId)
    {
        if (IsBusy)
            return;

        try
        {
            IsBusy = true;
            ErrorMessage = string.Empty;

            Movie = await _apiService.GetMovieByIdAsync(movieId);
            if (Movie == null)
            {
                ErrorMessage = "Film bulunamadı.";
                return;
            }

            // TODO: Kullanıcı ID'sini al
            int userId = 1; // Geçici olarak 1 kullanıyoruz
            UserRating = await _apiService.GetUserRatingAsync(userId, movieId);
            if (UserRating != null)
            {
                Rating = UserRating.Rating;
                Review = UserRating.Review ?? string.Empty;
            }
        }
        catch
        {
            ErrorMessage = "Film detayları yüklenirken bir hata oluştu.";
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task SaveRatingAsync()
    {
        if (IsBusy || Movie == null)
            return;

        try
        {
            IsBusy = true;
            ErrorMessage = string.Empty;

            // TODO: Kullanıcı ID'sini al
            int userId = 1; // Geçici olarak 1 kullanıyoruz

            var rating = new UserRating
            {
                UserId = userId,
                MovieId = Movie.Id,
                Rating = Rating,
                Review = Review
            };

            if (UserRating == null)
            {
                UserRating = await _apiService.CreateUserRatingAsync(rating);
            }
            else
            {
                UserRating = await _apiService.UpdateUserRatingAsync(rating);
            }

            if (UserRating != null)
            {
                // Başarılı - Film listesine dön
                await Shell.Current.GoToAsync("//FilmListPage");
            }
            else
            {
                ErrorMessage = "Değerlendirme kaydedilirken bir hata oluştu.";
            }
        }
        catch
        {
            ErrorMessage = "Değerlendirme kaydedilirken bir hata oluştu.";
        }
        finally
        {
            IsBusy = false;
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
} 