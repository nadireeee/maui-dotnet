using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using MovieApp.Maui.Models;
using MovieApp.Maui.Services;

namespace MovieApp.Maui.ViewModels;

public class ProfileViewModel : INotifyPropertyChanged
{
    private readonly ApiService _apiService;
    private User? _user;
    private ObservableCollection<Movie> _favoriteMovies = new();
    private Movie? _selectedFavoriteMovie;
    private bool _isBusy;
    private string _errorMessage = string.Empty;

    public ProfileViewModel(ApiService apiService)
    {
        _apiService = apiService;
        LoadUserCommand = new Command(async () => await LoadUserAsync());
        UpdatePasswordCommand = new Command(async () => await UpdatePasswordAsync());
        FavoriteMovieSelectedCommand = new Command<Movie>(async (movie) => await FavoriteMovieSelectedAsync(movie));
    }

    public User? User
    {
        get => _user;
        set
        {
            if (_user != value)
            {
                _user = value;
                OnPropertyChanged();
            }
        }
    }

    public ObservableCollection<Movie> FavoriteMovies
    {
        get => _favoriteMovies;
        set
        {
            if (_favoriteMovies != value)
            {
                _favoriteMovies = value;
                OnPropertyChanged();
            }
        }
    }

    public Movie? SelectedFavoriteMovie
    {
        get => _selectedFavoriteMovie;
        set
        {
            if (_selectedFavoriteMovie != value)
            {
                _selectedFavoriteMovie = value;
                OnPropertyChanged();
            }
        }
    }

    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (_isBusy != value)
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }
    }

    public string ErrorMessage
    {
        get => _errorMessage;
        set
        {
            if (_errorMessage != value)
            {
                _errorMessage = value;
                OnPropertyChanged();
            }
        }
    }

    public Command LoadUserCommand { get; }
    public Command UpdatePasswordCommand { get; }
    public Command<Movie> FavoriteMovieSelectedCommand { get; }

    private async Task LoadUserAsync()
    {
        if (IsBusy)
            return;

        try
        {
            IsBusy = true;
            ErrorMessage = string.Empty;

            // TODO: Kullanıcı ID'sini al
            int userId = 1; // Geçici olarak 1 kullanıyoruz
            User = await _apiService.GetUserByIdAsync(userId);
            if (User == null)
            {
                ErrorMessage = "Kullanıcı bilgileri yüklenemedi.";
            }
        }
        catch
        {
            ErrorMessage = "Kullanıcı bilgileri yüklenirken bir hata oluştu.";
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task UpdatePasswordAsync()
    {
        // Şifre güncelleme sayfasına yönlendir
        await Shell.Current.GoToAsync("PasswordUpdatePage");
    }

    private async Task FavoriteMovieSelectedAsync(Movie movie)
    {
        if (movie == null)
            return;
        await Shell.Current.GoToAsync($"FilmDetailPage?movieId={movie.Id}");
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
} 