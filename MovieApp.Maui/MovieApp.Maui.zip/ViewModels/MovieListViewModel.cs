using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using MovieApp.Maui.Models;
using MovieApp.Maui.Services;

namespace MovieApp.Maui.ViewModels;

public class MovieListViewModel : INotifyPropertyChanged
{
    private readonly ApiService _apiService;
    private ObservableCollection<Movie> _movies = new();
    private bool _isBusy;
    private string _searchText = string.Empty;
    private string _errorMessage = string.Empty;
    private Movie? _selectedMovie;
    private ObservableCollection<Movie> _allMovies = new();
    public Command FilterCommand { get; }
    private string _selectedFilter = "All";

    public MovieListViewModel(ApiService apiService)
    {
        _apiService = apiService;
        LoadMoviesCommand = new Command(async () => await LoadMoviesAsync());
        SearchCommand = new Command(async () => await SearchMoviesAsync());
        MovieSelectedCommand = new Command<Movie>(async (movie) => await MovieSelectedAsync(movie));
        FilterCommand = new Command<string>(OnFilterSelected);
    }

    public ObservableCollection<Movie> Movies
    {
        get => _movies;
        set
        {
            if (_movies != value)
            {
                _movies = value;
                OnPropertyChanged();
            }
        }
    }

    public bool IsBusy
    {
        get => _isBusy;
        set
        {
            if (_isBusy != value)
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }
    }

    public string SearchText
    {
        get => _searchText;
        set
        {
            if (_searchText != value)
            {
                _searchText = value;
                OnPropertyChanged();
            }
        }
    }

    public string ErrorMessage
    {
        get => _errorMessage;
        set
        {
            if (_errorMessage != value)
            {
                _errorMessage = value;
                OnPropertyChanged();
            }
        }
    }

    public Movie? SelectedMovie
    {
        get => _selectedMovie;
        set
        {
            if (_selectedMovie != value)
            {
                _selectedMovie = value;
                OnPropertyChanged();
            }
        }
    }

    public string SelectedFilter
    {
        get => _selectedFilter;
        set
        {
            if (_selectedFilter != value)
            {
                _selectedFilter = value;
                OnPropertyChanged();
                ApplyFilter();
            }
        }
    }

    public Command LoadMoviesCommand { get; }
    public Command SearchCommand { get; }
    public Command<Movie> MovieSelectedCommand { get; }

    public async Task LoadMoviesAsync()
    {
        if (IsBusy)
            return;

        try
        {
            IsBusy = true;
            ErrorMessage = string.Empty;

            var movies = await _apiService.GetMoviesAsync();
            _allMovies = new ObservableCollection<Movie>(movies);
            ApplyFilter();
        }
        catch
        {
            ErrorMessage = "Filmler yüklenirken bir hata oluştu.";
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task SearchMoviesAsync()
    {
        if (IsBusy)
            return;

        try
        {
            IsBusy = true;
            ErrorMessage = string.Empty;

            var movies = await _apiService.GetMoviesAsync();
            var filteredMovies = movies.Where(m => 
                m.Title.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ||
                m.Overview.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ||
                m.Director.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ||
                m.Cast.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ||
                m.Genres.Contains(SearchText, StringComparison.OrdinalIgnoreCase))
                .ToList();

            Movies = new ObservableCollection<Movie>(filteredMovies);
        }
        catch
        {
            ErrorMessage = "Filmler aranırken bir hata oluştu.";
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task MovieSelectedAsync(Movie movie)
    {
        if (movie == null)
            return;

        // Film detay sayfasına yönlendir
        await Shell.Current.GoToAsync($"FilmDetailPage?movieId={movie.Id}");
    }

    private void OnFilterSelected(string filter)
    {
        SelectedFilter = filter;
    }

    private void ApplyFilter()
    {
        if (_allMovies == null || !_allMovies.Any())
        {
            Movies = new ObservableCollection<Movie>();
            return;
        }
        IEnumerable<Movie> filtered = _allMovies;
        switch (SelectedFilter)
        {
            case "All":
                filtered = _allMovies;
                break;
            case "Action":
                filtered = _allMovies.Where(m => m.Genres.Contains("Action", StringComparison.OrdinalIgnoreCase) || m.Genres.Contains("Aksiyon", StringComparison.OrdinalIgnoreCase));
                break;
            case "Comedy":
                filtered = _allMovies.Where(m => m.Genres.Contains("Comedy", StringComparison.OrdinalIgnoreCase) || m.Genres.Contains("Komedi", StringComparison.OrdinalIgnoreCase));
                break;
            case "Drama":
                filtered = _allMovies.Where(m => m.Genres.Contains("Drama", StringComparison.OrdinalIgnoreCase) || m.Genres.Contains("Dram", StringComparison.OrdinalIgnoreCase));
                break;
            case "Horror":
                filtered = _allMovies.Where(m => m.Genres.Contains("Horror", StringComparison.OrdinalIgnoreCase) || m.Genres.Contains("Korku", StringComparison.OrdinalIgnoreCase));
                break;
            case "Romance":
                filtered = _allMovies.Where(m => m.Genres.Contains("Romance", StringComparison.OrdinalIgnoreCase) || m.Genres.Contains("Romantik", StringComparison.OrdinalIgnoreCase));
                break;
            case "Newest":
                filtered = _allMovies.OrderByDescending(m => m.ReleaseDate).Take(20);
                break;
            case "Popular":
                filtered = _allMovies.OrderByDescending(m => m.Popularity).Take(20);
                break;
            case "TopRated":
                filtered = _allMovies.OrderByDescending(m => m.VoteAverage).Take(20);
                break;
        }
        Movies = new ObservableCollection<Movie>(filtered);
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    protected virtual void OnPropertyChanged([CallerMemberName] string? propertyName = null)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
} 