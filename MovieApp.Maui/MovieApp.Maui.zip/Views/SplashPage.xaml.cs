namespace MovieApp.Maui.Views;

public partial class SplashPage : ContentPage
{
    public SplashPage()
    {
        InitializeComponent();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();

        // Oturum kontrolü vs.
        await Task.Delay(2000);
        await Shell.Current.GoToAsync("//LoginPage");
    }
}
