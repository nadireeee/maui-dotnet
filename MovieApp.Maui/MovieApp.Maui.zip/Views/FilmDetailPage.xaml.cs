using MovieApp.Maui.ViewModels;

namespace MovieApp.Maui.Views;

[QueryProperty(nameof(MovieId), "movieId")]
public partial class FilmDetailPage : ContentPage
{
    public int MovieId
    {
        get => (BindingContext as FilmDetailViewModel)?.MovieId ?? 0;
        set
        {
            if (BindingContext is FilmDetailViewModel vm)
                vm.MovieId = value;
        }
    }

    public FilmDetailPage(FilmDetailViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }
} 