using MovieApp.Maui.ViewModels;

namespace MovieApp.Maui.Views;

public partial class FilmListPage : ContentPage
{
    private readonly MovieListViewModel _viewModel;

    public FilmListPage(MovieListViewModel viewModel)
    {
        InitializeComponent();
        _viewModel = viewModel;
        BindingContext = _viewModel;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _viewModel.LoadMoviesAsync();
    }
} 