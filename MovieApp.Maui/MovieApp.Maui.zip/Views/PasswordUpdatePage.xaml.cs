using MovieApp.Maui.ViewModels;

namespace MovieApp.Maui.Views;

public partial class PasswordUpdatePage : ContentPage
{
    public PasswordUpdatePage(PasswordUpdateViewModel viewModel)
    {
        InitializeComponent();
        BindingContext = viewModel;
    }

    private async void OnBackToLoginClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("//LoginPage");
    }
} 