using MovieApp.Maui.ViewModels;

namespace MovieApp.Maui.Views;

public partial class ProfilePage : ContentPage
{
    private readonly ProfileViewModel _viewModel;

    public ProfilePage(ProfileViewModel viewModel)
    {
        InitializeComponent();
        _viewModel = viewModel;
        BindingContext = viewModel;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        _viewModel.LoadUserCommand.Execute(null);
    }

    private async void OnLogoutClicked(object sender, EventArgs e)
    {
        // TODO: Oturum kapatma işlemleri
        await Shell.Current.GoToAsync("//LoginPage");
    }
} 