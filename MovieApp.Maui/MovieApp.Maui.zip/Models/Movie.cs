namespace MovieApp.Maui.Models;

public class Movie
{
    public int Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Overview { get; set; } = string.Empty;
    public string PosterPath { get; set; } = string.Empty;
    public DateTime ReleaseDate { get; set; }
    public double VoteAverage { get; set; }
    public int VoteCount { get; set; }
    public string OriginalLanguage { get; set; } = string.Empty;
    public string OriginalTitle { get; set; } = string.Empty;
    public bool IsLocal { get; set; }
    public string Director { get; set; } = string.Empty;
    public string Cast { get; set; } = string.Empty;
    public string Genres { get; set; } = string.Empty;
    public int Runtime { get; set; }
    public string Tagline { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public decimal Budget { get; set; }
    public decimal Revenue { get; set; }
    public string ProductionCompanies { get; set; } = string.Empty;
    public string ProductionCountries { get; set; } = string.Empty;
    public string SpokenLanguages { get; set; } = string.Empty;
    public string Keywords { get; set; } = string.Empty;
    public string TrailerUrl { get; set; } = string.Empty;
    public string Homepage { get; set; } = string.Empty;
    public bool IsAdult { get; set; }
    public double Popularity { get; set; }
    public double? UserRatingAverage { get; set; }
    public int? UserRatingCount { get; set; }
    public int CreatedById { get; set; }
    public int? UpdatedById { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? UpdatedAt { get; set; }
} 